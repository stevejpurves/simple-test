---
venue: curvenote
subject: python programming
binder: https://xhrtcvh6l53u.curvenote.dev/services/binder/v2/gh/executablebooks/thebe-binder-base/HEAD
---

# Introduction

This article contains figures that originate in the notebook(s) in this project. And here are some EDITS.
Although I am not seeing the editing experience break

```{figure} figure3.png
:label: in-avif
AVIF
```

## Simple `matplotlib` plots

```{figure} #matplotlib-output
:label: in-md-label
da,da,da...
```

## A pandas table

```{figure} #wide-pandas-table

```

## A figure with a local image

```{figure} ./eruption.png

```

## Some interactive `ipywidgets` 😍

```{figure} #figure-cookies

```

### Some physics 🔭👨🏽‍🔬

```{figure} #figure-lorenz

```
