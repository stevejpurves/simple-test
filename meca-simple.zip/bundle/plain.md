---
title: Just Markdown
date: 31-mar-2023
venue: curvenote
authors:
  - name: Steve Purves
    corresponding: true
    email: steve@curvenote.com
    affiliations:
      - Curvenote
      - Executable Books
subject: python programming
---

# Introduction

This article contains figures that are just images

## A figure with a local image

```{figure} ./eruption.png

```
